# Importar el modelo Usuario desde el módulo común
from common.models.usuario import Usuario

# Puedes agregar otros modelos específicos de auth_service aquí si es necesario